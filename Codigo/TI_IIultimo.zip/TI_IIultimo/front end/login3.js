const form = document.getElementById("loginForm");
function getUser() {
    let xhr = new XMLHttpRequest();
    
    let email = document.getElementById("email").value;
    let password = document.getElementById("senha").value;
    let actionSrc = `http://localhost:6789/usuario/login/${email}/${password}`;
    
    xhr.open( "GET", actionSrc);
    xhr.send();
    function reqListener() {
        console.log(this.responseText);
      }
  
      xhr.onreadystatechange = function() {
        if (this.readyState == 4 && this.status == 200) {
          document.getElementById("timer").innerHTML = this.responseText;
        }
    //  xhr.addEventListener("load", reqListener);
    /*xhr.addEventListener( 'load', function ( event ) {
        verifyUser(event.target.responseText, password);
    } );*/

    // Define case error
    //xhr.addEventListener( ' error', function ( event ) {
      //  alert ( 'Oops! ' );
    //} );

   

   // xhr.send();
}

/*function verifyUser( user, password) {
    let objUser = JSON.parse(user);
    // Verificação de senha
    if(objUser.senha == password) {
        window.location.replace("/index.html");
        localStorage.setItem('email', JSON.stringify(objUser.email));
    } else {
        alert("Senha incorreta!");
        window.location.replace("html/login_cadastro/login.html");
    }
}
    */
}

window.addEventListener("load", function () { 
    form.addEventListener( "submit", function ( event ) {
      event.preventDefault();
    /*    const url = "http://localhost:6789/usuario/login/lll@gmail.com/123";
     //  const url= "https://randomuser.me/api/";

fetch(url)
  .then(
    response => response.text() // .json(), .blob(), etc.
  ).then(
    text => console.log(text) // Handle here
  );
  */
  const requestOptions = {
    method: "GET",
    redirect: "follow"
  };
  
  fetch("http://localhost:6789/usuario/login/lll@gmail.com/123", requestOptions)
    .then((response) => response.text())
    .then((result) => console.log(result))
    .catch((error) => console.error(error));
       
       // getUser();
        });
    });