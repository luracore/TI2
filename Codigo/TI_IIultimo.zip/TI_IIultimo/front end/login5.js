
document.addEventListener("DOMContentLoaded", function () {
    const form = document.getElementById("loginForm");
    let idarmazenado=Number(localStorage.getItem("id"));
    if (form) {
        form.addEventListener("submit", function (event) {
            event.preventDefault(); // Prevent default form submission
            getUser(); // Call the getUser function
        });
    } else {
        console.error("Form element with ID 'loginForm' not found.");
    }

    function addCode() {
        document.getElementById("add_to_me")
            .innerHTML +=
            `  <button class="logout-button" onclick="logout()">Deslogar</button>`;
    }
   
    if(idarmazenado!=0){
        addCode();

   
}

function logout() {
    alert("Você foi deslogado!");
    // Clear session or local storage if needed
    localStorage.clear();
    sessionStorage.clear();
    window.location.href = "index.html"; // Redirect to home or login page
}
    function getUser() {
        const email = document.getElementById("email").value;
        const password = document.getElementById("senha").value;
        const actionSrc = `http://localhost:6789/usuario/login/${email}/${password}`;

        // Use Axios to send the GET request
        axios
            .get(actionSrc)
            .then((response) => {
                console.log("Server response:", response.data); // Log the response
                document.getElementById("timer").innerHTML = response.data;
                localStorage.setItem("id", response.data);
                alert("log  in efetuado!");
                location.reload();

            })
            .catch((error) => {
                console.error("Request error:", error); // Log the error
                alert("Login failed. Check the console for more details.");
            });
    }

 
});
