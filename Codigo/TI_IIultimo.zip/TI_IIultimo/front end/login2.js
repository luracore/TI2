// Access form element
const form = document.getElementById("loginForm");

function getUser() {
    var http = new XMLHttpRequest();
    var url = 'http://localhost:6789/usuario/login';
    let email = document.getElementById("email").value;
    let password = document.getElementById("senha").value;

    // Prepare request
    http.open('POST', url, true);

    var params = new Object();
    params.email = email;
    params.senha = password;

    let urlEncodedData = "", urlEncodedDataPairs = [], parametros;

    for (parametros in params) {
        urlEncodedDataPairs.push(
            encodeURIComponent(parametros) + '=' + encodeURIComponent(params[parametros])
        );
    }

    urlEncodedData = urlEncodedDataPairs.join("&");

    // Send the proper header information along with the request
    http.setRequestHeader('Content-type', 'application/x-www-form-urlencoded');

    http.onreadystatechange = function () { // Call a function when the state changes.
       // if (http.readyState == 4 && http.status == 200) {
            alert(http.responseText); // Success response


      //  } else if (http.readyState == 4) {
           // alert("An error occurred: " + http.status); // Error response
       // }
    };

    // Send the request
    http.send(urlEncodedData);
}
function salvardados(objeto){
    
    let objusuario=JSON.parse(objeto);
    window.location.replace("/index.html");
    SessionStorage.setItem('id', JSON.stringify(objUser.id));

}

window.addEventListener("load", function () { 
    form.addEventListener("submit", function (event) {
        event.preventDefault(); // Prevent form default submission
        getUser(); // Call getUser function
    });
});
