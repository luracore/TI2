
document.addEventListener("DOMContentLoaded", function () {

    let idarmazenado=Number(localStorage.getItem("id"));
    /*if (form) {
        form.addEventListener("submit", function (event) {
            event.preventDefault(); // Prevent default form submission
            getUser(); // Call the getUser function
        });
    } else {
        console.error("Form element with ID 'loginForm' not found.");
    }
        */

    function addCode() {

        document.getElementById("add_to_me")
            .innerHTML +=
            ` <section class="section--row__responsive">
    <h1 class="generaltext">Listar alimentos em sua conta</h1>
    <form action="http://localhost:6789/alimento/usuario" method="get" id="form-lista">
        <br><br><br>
         <input type = "hidden" id = "usuario" name="usuario" />
    </form>
</section> `;
    }
   
    if(idarmazenado!=0){

        addCode();


   
}
const form = document.getElementById("form-lista");
 form.addEventListener("submit", function (event) {
    document.getElementById('usuario').value = id;
 });
   

 
});
