document.addEventListener("DOMContentLoaded", function () {
    const form = document.getElementById("loginForm");

    function getUser() {
        const email = document.getElementById("email").value;
        const password = document.getElementById("senha").value;
        const actionSrc = `http://localhost:6789/usuario/login/${email}/${password}`;

        // Use Axios to send the GET request
        axios
            .get(actionSrc)
            .then((response) => {
                console.log("Server response:", response.data); // Log the response
                document.getElementById("timer").innerHTML = response.data;
                localStorage.setItem("id", response.data);

            })
            .catch((error) => {
                console.error("Request error:", error); // Log the error
                alert("Login failed. Check the console for more details.");
            });
    }

    if (form) {
        form.addEventListener("submit", function (event) {
            event.preventDefault(); // Prevent default form submission
            getUser(); // Call the getUser function
        });
    } else {
        console.error("Form element with ID 'loginForm' not found.");
    }
});
