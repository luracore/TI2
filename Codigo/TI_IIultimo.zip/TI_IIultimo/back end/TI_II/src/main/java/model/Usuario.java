package model;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.io.Serializable;
import java.time.LocalDate;
import java.time.LocalDateTime;

public class Usuario implements Serializable {
	private static final long serialVersionUID = 1L;
	public static final String DESCRICAO_PADRAO = "Novo Produto";
	public static final int MAX_ESTOQUE = 1000;
	private int id;
	private String nome;
	private float peso;
	private int altura;
	private LocalDateTime dataFabricacao;	
	private LocalDate dataValidade;
	private String senha;
	private float IMC;
	private String email;
	public Usuario() {
		id = -1;
		nome = DESCRICAO_PADRAO;
		peso = 0.01F;
		altura = 0;
		senha=DESCRICAO_PADRAO;
		//dataFabricacao = LocalDateTime.now();
		//dataValidade = LocalDate.now().plusMonths(6); // o default é uma validade de 6 meses.
		IMC=0;
	}
	public  String hashSenhaToMD5(String senha) {
        try {
            // Create MessageDigest instance for MD5
            MessageDigest md = MessageDigest.getInstance("MD5");
            
            // Add name bytes to digest
            md.update(senha.getBytes());
            
            // Get the hash's bytes
            byte[] bytes = md.digest();
            
            // Convert it to hexadecimal format
            StringBuilder sb = new StringBuilder();
            for (byte b : bytes) {
                sb.append(String.format("%02x", b));
            }
            
            // Get complete hashed name in hex format
            return sb.toString();
        } catch (NoSuchAlgorithmException e) {
            throw new RuntimeException(e);
        }
    }

	public Usuario(int id, String nome, float peso, int altura, String senha,String email) {
		setId(id);
		
		setPeso(peso);
		setAlt(altura);
		setEmail(email);

	setSenha(senha);
	
	setNome(nome);
		setIMC(altura,peso);
		
		
	}
	public Usuario(Usuario usuario) {
        this.id = usuario.id;
        this.nome = usuario.nome;
        this.peso = usuario.peso;
        this.altura = usuario.altura;
        this.senha = usuario.senha;
        this.email = usuario.email;
    }
	
	
	public int getId() {
		return id;
	}
	


	public void setId(int id) {
		this.id = id;
	}
	
	public String getEmail() {
		return email;
	}
	
	
	public void setEmail(String email) {
		this.email=email;
	}
	

	
	public String getNome() {
		return nome;
	}

	public void setNome(String nome) {
		if (nome.length() >= 3)
			this.nome = nome;
	}

	public float getPeso() {
		return peso;
	}

	public void setPeso(float peso) {
		if (peso > 0)
			this.peso = peso;
	}

	public int getAlt() {
		return altura;
	}
	
	public void setAlt(int altura) {
		if (altura >= 0 && altura <= MAX_ESTOQUE)
			this.altura = altura;
	}
	
	public LocalDate getDataValidade() {
		return dataValidade;
	}

	public String  getSenha() {
		return senha;
	}

	public void setSenha(String senha) {
			this.senha = senha;
	}
	public float  getIMC() {
		return IMC;
	}

	public void setIMC(int altura,float peso) {
		float  IMC=peso/(altura*altura);
		this.IMC = IMC;
	}	

	public void setDataValidade(LocalDate dataValidade) {
		// a data de fabricação deve ser anterior é data de validade.
	
			this.dataValidade = dataValidade;
	}

	public boolean emValidade() {
		return LocalDateTime.now().isBefore(this.getDataValidade().atTime(23, 59));
	}

	/**
	 * Método sobreposto da classe Object. É executado quando um objeto precisa
	 * ser exibido na forma de String.
	 */
	@Override
	/*public String toString() {
		return "{ \"id \":"+id + "  }";
	}
	
	  
	 */
	/*public String toString() {
		return "Produto: " + nome + "   Preço: R$" + peso + "   Alt.: " + altura + "   Fabricação: "
				+ dataFabricacao  + "   Data de Validade: " + dataValidade;
	}
	*/
	public String toString() {
		return Integer.toString(id);
	}
	
	
	@Override
	public boolean equals(Object obj) {
		return (this.getId() == ((Usuario) obj).getId());
	}


}