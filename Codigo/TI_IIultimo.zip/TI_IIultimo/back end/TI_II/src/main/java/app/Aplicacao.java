package app;
import dao.DAO;
import dao.Alimentodao;


import static spark.Spark.*;

import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;

import service.UsuarioService;
import service.AlimentoService;

public class Aplicacao {
	
	
	
	
	private static UsuarioService usuarioService = new UsuarioService();
	private static AlimentoService alimentoService=new AlimentoService();
    public static void main(String[] args) {
    	
    	
    	 try {
    		 System.out.println("entrou no try");
         	String senha="123";
         	
             // Create MessageDigest instance for MD5
             MessageDigest md = MessageDigest.getInstance("MD5");
             
             // Add name bytes to digest
             md.update(senha.getBytes());
             
             // Get the hash's bytes
             byte[] bytes = md.digest();
             
             // Convert it to hexadecimal format
             StringBuilder sb = new StringBuilder();
             for (byte b : bytes) {
                 sb.append(String.format("%02x", b));
             }
             
             // Get complete hashed name in hex format
              sb.toString();
         } catch (NoSuchAlgorithmException e) {
             throw new RuntimeException(e);
         }
    	System.out.println("aaaaaogorasso");
        port(6789);
       
          
        

        post("/usuario", (request, response) -> usuarioService.add(request, response));

        get("/usuario/:id", (request, response) -> usuarioService.get(request, response));
        get("/usuario/updateinfo/:nome", (request, response) -> usuarioService.get(request, response));
        get("/usuario/login/:email/:senha", (request, response) -> usuarioService.login(request, response));

        post("/usuario/update", (request, response) -> usuarioService.update(request, response));
        post("/alimento/update", (request, response) -> alimentoService.update(request, response));
        //post("/usuario/login", (request, response) -> usuarioService.login(request, response));

        get("/usuario/delete/:id", (request, response) -> usuarioService.remove(request, response));

        get("/usuario", (request, response) -> usuarioService.getAll(request, response));
        
        get("/usuario/search/:username", (request, response) -> usuarioService.search(request, response));
        get("/usuario/search", (request, response) -> usuarioService.searchogro(request, response));
        post("/alimento", (request, response) -> alimentoService.add(request, response));

        get("/alimento/:id", (request, response) -> alimentoService.get(request, response));

        //post("/alimento/update", (request, response) -> alimentoService.update(request, response));
        
        get("/alimento/delete/:id", (request, response) -> alimentoService.remove(request, response));

        get("/alimento", (request, response) -> alimentoService.getAll(request, response));
        get("/alimento/AI/:nome", (request, response) -> alimentoService.getAI(request, response));
        get("/alimento/:usuario", (request, response) -> alimentoService.getAI(request, response));

        
               
    }
}