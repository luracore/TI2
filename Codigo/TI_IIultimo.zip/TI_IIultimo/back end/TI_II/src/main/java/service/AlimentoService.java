package service;

import java.io.IOException;
import java.time.LocalDate;
import java.time.LocalDateTime;

import dao.Alergiadao;
import dao.Alimentodao;
//import alimentodao.AlimentoAlimentoalimentodao;
import model.Alimento;

import spark.Request;
import spark.Response;
import dao.Alimentodao;


public class AlimentoService {
	
	
	//static Alimentoalimentodao alimentodao = new Alimentoalimentodao();


	//private AlimentoAlimentoalimentodao alimentoAlimentoalimentodao;
	private Alimentodao alimentodao;
	private Alergiadao alergiadao;

	public AlimentoService() {
		try {
			//alimentoAlimentoalimentodao = new AlimentoAlimentoalimentodao("alimento.dat");
			alimentodao=new Alimentodao();
			
			
			alimentodao.conectar();
			alimentodao.iniciar();
			alergiadao=new Alergiadao();
			alergiadao.conectar();
			alergiadao.iniciar();
			int idteste=alimentodao.maxid()+2;
			System.out.println(idteste+"aaab");
		} catch (Exception  e) {
			System.out.println(e.getMessage());
		}
	}

	public Object add(Request request, Response response) {
		System.out.println("elizeta");
		String nome = request.queryParams("nome");
		int  proteinas = Integer.parseInt(request.queryParams("proteina"));
		int calorias = Integer.parseInt(request.queryParams("calorias"));
		int  usuario  = Integer.parseInt(request.queryParams("usuario"));
		String alergia  = request.queryParams("alergias");
		
		
		
		//int alimento_id = Integer.parseInt(request.queryParams("alimento_id"));

		//int id = alimentoAlimentoalimentodao.getMaxId() + 1;
int id=alimentodao.maxid()+1;
System.out.println(id+"aaa");

		Alimento alimento = new Alimento(id, nome, proteinas, calorias,usuario);

		//alimentoAlimentoalimentodao.add(alimento);
alimentodao.inserirAlimento(alimento);
		response.status(201); // 201 Created
		return id;
	}

	public Object get(Request request, Response response) {
		int id = Integer.parseInt(request.params(":id"));
		
		//Alimento alimento = (Alimento) alimentoAlimentoalimentodao.get(id);
		Alimento alimento = (Alimento) alimentodao.get(id);
	
		
		if (alimento != null) {
			 response.header("Content-Type", "text/html");
		        response.header("Content-Encoding", "UTF-8");
    	    String htmlResponse = "<html>\n" +
	                "<head>\n" +
	                "<meta http-equiv=\"refresh\" content=\"5;url=conta.html\">\n" + // Redireciona após 5 segundos
	                "<title>Usuário Encontrado</title>\n" +
	                "</head>\n" +
	                "<body>\n" +
	                "<h1>Usuário</h1>\n" +
	                "<p>ID: " + alimento.getId() + "</p>\n" +
	                "<p>Nome: " + alimento.getNome() + "</p>\n" +
	                "<p>Peso: " + alimento.getProteinas() + "</p>\n" +
	                "<p>Altura: " + alimento.getCalorias() + "</p>\n" +
	                "<p>Você será redirecionado para <a href=\"conta.html\">conta.html</a> em 5 segundos.</p>\n" +
	                "<script> \n  window.location.href = 'conta.html';  </script>\n" +
	                "</body>\n" +
	                "</html>";

	        return htmlResponse;
            
        } else {
            response.status(404); // 404 Not found
            return "Alimento " + id + " não encontrado.";
        }

	}
	
	public Object getAI(Request request, Response response) {
		 String nome = request.params(":nome");
		
		//Alimento alimento = (Alimento) alimentoAlimentoalimentodao.get(id);
		Alimento alimento = (Alimento) alimentodao.pesquisar_alimento(nome);
		if (alimento != null) {
			 response.header("Content-Type", "text/html");
		        response.header("Content-Encoding", "UTF-8");
   	    String htmlResponse = "<html>\n" +
	                "<head>\n" +
	                "<title>Alimento Encontrado</title>\n" +
	                "</head>\n" +
	                "<body>\n" +
	                "<h1>Alimento</h1>\n" +
	                "<p>ID: " + alimento.getId() + "</p>\n" +
	                "<p>Nome: " + alimento.getNome() + "</p>\n" +
	                "<p>Proteinas: " + alimento.getProteinas() + "</p>\n" +
	                "<p>Calorias: " + alimento.getCalorias() + "</p>\n" +
	                "</body>\n" +
	                "</html>";

	        return htmlResponse;
           
       }
		
	/*-	if (alimento != null) {
    	    response.header("Content-Type", "application/xml");
    	    response.header("Content-Encoding", "UTF-8");

            return "<alimento>\n" + 
            		"\t<id>" + alimento.getId() + "</id>\n" +
            		"\t<nome>" + alimento.getNome() + "</nome>\n" +
            		"\t<proteinas>" + alimento.getProteinas() + "</proteinas>\n" +
            		"\t<calorias>" + alimento.getCalorias() + "</calorias>\n" +
            		
            		"</alimento>\n";
        } */
		
		else {
            response.status(404); // 404 Not found
            return "Alimento " + nome  + " não encontrado.";
        }

	}
	
	


	
	
	public Object update(Request request, Response response) {
        int id = Integer.parseInt(request.queryParams("id"));
        
		Alimento alimento = (Alimento) alimentodao.get(id);

        if (alimento != null) {
        	System.out.println(alimento.getNome());
        	alimento.setNome(request.queryParams("nome"));
        	alimento.setCalorias(Integer.parseInt(request.queryParams("calorias")));
        	alimento.setProteinas(Integer.parseInt(request.queryParams("proteinas")));
        	

        	alimentodao.atualizarAlimento(alimento);
        	
            return id;
        } else {
            response.status(404); // 404 Not found
            return "alimento não encontrado.";
        }

	}

	public Object remove(Request request, Response response) {
        int id = Integer.parseInt(request.params(":id"));

        Alimento alimento = (Alimento) alimentodao.get(id);

        if (alimento != null) {

            alimentodao.excluirAlimento(alimento);

            response.status(200); // success
        	return id;
        } else {
            response.status(404); // 404 Not found
            return "Alimento não encontrado.";
        }
	}
	

	public Object getAll(Request request, Response response) {
	    StringBuffer returnValue = new StringBuffer(
	        "<!DOCTYPE html>\n" +
	        "<html lang=\"en\">\n" +
	        "<head>\n" +
	        "    <meta charset=\"UTF-8\">\n" +
	        "    <meta name=\"viewport\" content=\"width=device-width, initial-scale=1.0\">\n" +
	        "    <title>Lista de Alimentos</title>\n" +
	        "    <style>\n" +
	        "        table {\n" +
	        "            width: 100%;\n" +
	        "            border-collapse: collapse;\n" +
	        "        }\n" +
	        "        table, th, td {\n" +
	        "            border: 1px solid black;\n" +
	        "        }\n" +
	        "        th, td {\n" +
	        "            padding: 15px;\n" +
	        "            text-align: left;\n" +
	        "        }\n" +
	        "        th {\n" +
	        "            background-color: #f2f2f2;\n" +
	        "        }\n" +
	        "    </style>\n" +
	        "</head>\n" +
	        "<body>\n" +
	        "    <h1>Lista de Alimentos</h1>\n" +
	        "    <table>\n" +
	        "        <tr>\n" +
	        "            <th>ID</th>\n" +
	        "            <th>Nome</th>\n" +
	        "            <th>Proteínas</th>\n" +
	        "            <th>Calorias</th>\n" +
	        "        </tr>\n");

	    for (Alimento alimento : alimentodao.getAlimentos()) {
	        returnValue.append(
	            "        <tr>\n" +
	            "            <td>" + alimento.getId() + "</td>\n" +
	            "            <td>" + alimento.getNome() + "</td>\n" +
	            "            <td>" + alimento.getProteinas() + "</td>\n" +
	            "            <td>" + alimento.getCalorias() + "</td>\n" +
	            "        </tr>\n"
	        );
	    }

	    returnValue.append(
	        "    </table>\n" +
	        "</body>\n" +
	        "</html>\n"
	    );

	    response.header("Content-Type", "text/html");
	    response.header("Content-Encoding", "UTF-8");
	    return returnValue.toString();
	}
	
	public Object getAlimentouser(Request request, Response response) {
	    StringBuffer returnValue = new StringBuffer(
	        "<!DOCTYPE html>\n" +
	        "<html lang=\"en\">\n" +
	        "<head>\n" +
	        "    <meta charset=\"UTF-8\">\n" +
	        "    <meta name=\"viewport\" content=\"width=device-width, initial-scale=1.0\">\n" +
	        "    <title>Lista de Alimentos</title>\n" +
	        "    <style>\n" +
	        "        table {\n" +
	        "            width: 100%;\n" +
	        "            border-collapse: collapse;\n" +
	        "        }\n" +
	        "        table, th, td {\n" +
	        "            border: 1px solid black;\n" +
	        "        }\n" +
	        "        th, td {\n" +
	        "            padding: 15px;\n" +
	        "            text-align: left;\n" +
	        "        }\n" +
	        "        th {\n" +
	        "            background-color: #f2f2f2;\n" +
	        "        }\n" +
	        "    </style>\n" +
	        "</head>\n" +
	        "<body>\n" +
	        "    <h1>Lista de Alimentos</h1>\n" +
	        "    <table>\n" +
	        "        <tr>\n" +
	        "            <th>ID</th>\n" +
	        "            <th>Nome</th>\n" +
	        "            <th>Proteínas</th>\n" +
	        "            <th>Calorias</th>\n" +
	        "        </tr>\n");

	    for (Alimento alimento : alimentodao.getAlimentos()) {
	    	if(alimento.getUsuario_id())
	        returnValue.append(
	            "        <tr>\n" +
	            "            <td>" + alimento.getId() + "</td>\n" +
	            "            <td>" + alimento.getNome() + "</td>\n" +
	            "            <td>" + alimento.getProteinas() + "</td>\n" +
	            "            <td>" + alimento.getCalorias() + "</td>\n" +
	            "        </tr>\n"
	        );
	    }

	    returnValue.append(
	        "    </table>\n" +
	        "</body>\n" +
	        "</html>\n"
	    );

	    response.header("Content-Type", "text/html");
	    response.header("Content-Encoding", "UTF-8");
	    return returnValue.toString();
	}

}
